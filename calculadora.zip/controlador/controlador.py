class CalculadoraControlador:
    def __init__(self, modelo, vista):
        self.modelo = modelo
        self.vista = vista
        self.vista.btnSumar.config(command=self.sumar)
        self.vista.btnRestar.config(command=self.restar)
        self.vista.btnMultiplicar.config(command=self.multiplicar)
        self.vista.btnDividir.config(command=self.dividir)

    def sumar(self):
        num1 = float(self.vista.num1.get())
        num2 = float(self.vista.num2.get())
        self.modelo.sumar(num1, num2)
        self.vista.mostrar_resultado(self.modelo.resultado)

    def restar(self):
        num1 = float(self.vista.num1.get())
        num2 = float(self.vista.num2.get())
        self.modelo.restar(num1, num2)
        self.vista.mostrar_resultado(self.modelo.resultado)

    def multiplicar(self):
        num1 = float(self.vista.num1.get())
        num2 = float(self.vista.num2.get())
        self.modelo.multiplicar(num1, num2)
        self.vista.mostrar_resultado(self.modelo.resultado)

    def dividir(self):
        num1 = float(self.vista.num1.get())
        num2 = float(self.vista.num2.get())
        try:
            self.modelo.dividir(num1, num2)
            self.vista.mostrar_resultado(self.modelo.resultado)
        except ZeroDivisionError:
            self.vista.mostrar_resultado("Error: No se puede dividir entre cero.")

if __name__ == "__main__":
    modelo = CalculadoraModelo()
    vista = CalculadoraVista()
    controlador = CalculadoraControlador(modelo, vista)
    vista.run()
