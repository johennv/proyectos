import tkinter as tk

from controlador.controlador import CalculadoraControlador
from vista.vista import CalculadoraVista
from modelo.modelo import CalculadoraModelo

if __name__ == "__main__":
    modelo = CalculadoraModelo()
    vista = CalculadoraVista()
    controlador = CalculadoraControlador(modelo, vista)
    vista.run()

