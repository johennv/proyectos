class CalculadoraVista:
    def __init__(self):
        self.ventana = tk.Tk()
        self.ventana.title("Calculadora MVC")
        self.ventana.geometry("400x300")
        self.ventana.configure(bg="#f2f2f2")  # Color de fondo

        estilo_label = {
            "font": ("Arial", 14),
            "bg": "#f2f2f2",
            "fg": "#333333"
        }

        estilo_entry = {
            "font": ("Arial", 14),
            "bg": "#ffffff",
            "fg": "#333333",
            "bd": 1,
            "relief": "solid",
            "justify": "right"
        }

        estilo_boton = {
            "font": ("Arial", 14),
            "bg": "#e0e0e0",
            "fg": "#333333",
            "bd": 0,
            "width": 10,
            "height": 2
        }

        self.modelo = CalculadoraModelo()

        # Etiquetas
        self.label_num1 = tk.Label(self.ventana, text="Número 1:", **estilo_label)
        self.label_num1.grid(row=0, column=0, padx=10, pady=10)

        # Campos de entrada de texto
        self.num1 = tk.Entry(self.ventana, **estilo_entry)
        self.num1.grid(row=0, column=1, padx=10, pady=10)

        self.label_num2 = tk.Label(self.ventana, text="Número 2:", **estilo_label)
        self.label_num2.grid(row=1, column=0, padx=10, pady=10)

        # Campos de entrada de texto
        self.num2 = tk.Entry(self.ventana, **estilo_entry)
        self.num2.grid(row=1, column=1, padx=10, pady=10)

        # Botones de las operaciones
        self.btnSumar = tk.Button(self.ventana, text="Sumar", **estilo_boton)
        self.btnSumar.grid(row=2, column=0, padx=10, pady=10)

        self.btnRestar = tk.Button(self.ventana, text="Restar", **estilo_boton)
        self.btnRestar.grid(row=2, column=1, padx=10, pady=10)

        self.btnMultiplicar = tk.Button(self.ventana, text="Multiplicar", **estilo_boton)
        self.btnMultiplicar.grid(row=3, column=0, padx=10, pady=10)

        self.btnDividir = tk.Button(self.ventana, text="Dividir", **estilo_boton)
        self.btnDividir.grid(row=3, column=1, padx=10, pady=10)

        self.resultado_label = tk.Label(self.ventana, text="Resultado:", **estilo_label)
        self.resultado_label.grid(row=4, column=0, padx=10, pady=10)

        self.resultado_entry = tk.Entry(self.ventana, **estilo_entry)
        self.resultado_entry.grid(row=4, column=1, padx=10, pady=10)

        # Botón de reinicio
        self.btnReiniciar = tk.Button(self.ventana, text="Reiniciar", **estilo_boton)
        self.btnReiniciar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)
        self.btnReiniciar.config(command=self.reiniciar)

    def run(self):
        self.ventana.mainloop()

    def mostrar_resultado(self, resultado):
        self.resultado_entry.delete(0, tk.END)
        self.resultado_entry.insert(0, str(resultado))

    def reiniciar(self):
        self.num1.delete(0, tk.END)
        self.num2.delete(0, tk.END)
        self.modelo.reiniciar()
        self.mostrar_resultado(self.modelo.resultado)